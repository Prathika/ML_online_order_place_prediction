
# coding: utf-8

# In[23]:


# Read the CSV data using pandas
import pandas as pd
train_data = pd.read_csv("training_data.csv")
test_data = pd.read_csv("test_data .csv")
pd.get_dummies(train_data.funnel_level)
pd.get_dummies(test_data.funnel_level)
train_data.tail()


# In[2]:


# A glimpse of train data
train_data.describe(include='all').head()


# In[3]:


# A glimpse of test_data
test_data.describe(include='all')


# In[4]:


# Check the data count for both test and train data
print(train_data.shape)
print(test_data.shape)


# In[5]:


# Use seaborn to check make EDA(Exploratory Data Analysis)
import seaborn as sns
sns.countplot(data=train_data,x='checkout',hue='order_placed')


# In[6]:


#Dropping checkout field as it will not be accounted in the test data
train_data.drop(['checkout'],axis=1)
train_data.tail()


# In[7]:


sns.set_style('whitegrid')
sns.countplot(x='order_placed',data=train_data,palette='RdBu_r')
# This plot shows us that the order_placed is less than order_ not placed


# In[8]:


#Visualise data based on the funnel_level field
sns.set_style('whitegrid')
sns.countplot(x='order_placed',hue='funnel_level',data=train_data,palette='rainbow')


# In[9]:


# Get an idea of which value of the target attribute is dominant with the traindata
train_data.order_placed.value_counts()


# In[10]:


# Get field info of all train data
train_data.info()


# In[11]:


def trim_prefix_grp(data):
    return data.split('grp')[1]


# In[12]:


# For futher model prediction we need the numeric data. Cleanse and tranform the grp field accordingly
train_data['grp'] = train_data['grp'].apply(trim_prefix_grp)
test_data['grp'] = test_data['grp'].apply(trim_prefix_grp)
train_data.head()


# In[13]:


def trim_prefix_link(data):
    return data.split('link')[1]
train_data['link'] = train_data['link'].apply(trim_prefix_link)
test_data['link'] = test_data['link'].apply(trim_prefix_link)


# In[14]:


test_data.head()


# In[15]:


# Cleansing the id field
def trim_prefix_session(data):
    return data.split('session')[1]
train_data['id'] = train_data['id'].apply(trim_prefix_session)
test_data['id'] = test_data['id'].apply(trim_prefix_session)


# In[16]:



# Susbtitue the value for categorical data
#funnel = {'upper':1, 'middle':2, 'lower':3}

# X_train - Independet variables
# Y_train - Dependent or Target variables
# 
#train_data['funnel_level'] = train_data['funnel_level'].apply(lambda x: funnel.get(x))
#X_train = train_data[['id','grp', 'funnel_level','link']]
#Y_train = train_data['order_placed']


#test_data = test_data[['id','grp', 'funnel_level','link']]
#test_data['funnel_level'] = test_data['funnel_level'].apply(lambda x: funnel.get(x))
#test_data.head()
pd.get_dummies(train_data.funnel_level)
pd.get_dummies(test_data.funnel_level)
X_train = train_data[['id','grp', 'funnel_level','link']]
Y_train = train_data['order_placed']

train_data.head()


# In[17]:


test_data.tail()


# In[18]:


X_train.head()


# In[19]:


X_test = test_data
X_test.head()


# In[20]:


Y_train.head()


# In[21]:


def prepend_session(data):
    return 'session{}'.format(data)


# In[22]:


from sklearn.linear_model import LogisticRegression
model = LogisticRegression()

model.fit(X_train, Y_train)
model_score = model.score(X_train, Y_train)
print("Logistic Regression Score",model_score)

my_log_prediction = model.predict(X_test)
my_log_solution = pd.DataFrame(my_log_prediction, X_test.id.apply(prepend_session), columns = ["order_placed"])
my_log_solution.to_csv("TG3_ML_with_link_col_log_regression.csv", index_label = ["id"])


# In[ ]:


from sklearn.ensemble import RandomForestClassifier
forest = RandomForestClassifier(max_depth=10,min_samples_split=2,n_estimators=100 , random_state=1 )
rf_model = forest.fit(X_train,Y_train)
rf_model_score = rf_model.score(X_train, Y_train)
print("Random Forest Score",rf_model_score)
my_prediction = rf_model.predict(X_test)

my_solution = pd.DataFrame(my_prediction, X_test.id.apply(prepend_session), columns = ["order_placed"])

my_solution.to_csv("TG3_ML_with_link_col_random_forest.csv", index_label = ["id"])

